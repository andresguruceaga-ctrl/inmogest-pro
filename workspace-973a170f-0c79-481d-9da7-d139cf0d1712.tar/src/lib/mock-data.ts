import { Property, Owner, Tenant, Contract, ServiceRequest, User } from '@/types';

// Sample Users for Demo Mode
export const users: User[] = [
  {
    id: 'user-1',
    name: 'Carlos García',
    email: 'admin@inmobiliaria.es',
    role: 'admin',
    avatar: 'CG'
  },
  {
    id: 'user-2',
    name: 'María Rodríguez',
    email: 'maria.rodriguez@email.es',
    role: 'owner',
    avatar: 'MR'
  },
  {
    id: 'user-3',
    name: 'Juan Martínez',
    email: 'juan.martinez@email.es',
    role: 'tenant',
    avatar: 'JM'
  }
];

// Sample Owners
export const owners: Owner[] = [
  {
    id: 'owner-1',
    name: 'María Rodríguez',
    email: 'maria.rodriguez@email.es',
    phone: '+34 612 345 678',
    address: 'Calle Serrano 45, Madrid',
    properties: ['prop-1', 'prop-2', 'prop-5'],
    createdAt: '2023-01-15'
  },
  {
    id: 'owner-2',
    name: 'Antonio Fernández',
    email: 'antonio.fernandez@email.es',
    phone: '+34 623 456 789',
    address: 'Paseo de Gracia 78, Barcelona',
    properties: ['prop-3', 'prop-4', 'prop-6'],
    createdAt: '2023-02-20'
  },
  {
    id: 'owner-3',
    name: 'Isabel López',
    email: 'isabel.lopez@email.es',
    phone: '+34 634 567 890',
    address: 'Calle Colón 12, Valencia',
    properties: ['prop-7', 'prop-8'],
    createdAt: '2023-03-10'
  },
  {
    id: 'owner-4',
    name: 'Pedro Sánchez',
    email: 'pedro.sanchez@email.es',
    phone: '+34 645 678 901',
    address: 'Calle Gran Vía 34, Bilbao',
    properties: ['prop-9', 'prop-10'],
    createdAt: '2023-04-05'
  }
];

// Sample Properties - 10 Spanish properties
export const properties: Property[] = [
  {
    id: 'prop-1',
    name: 'Ático con Terraza en Salamanca',
    address: 'Calle Serrano 156, 6º D',
    city: 'Madrid',
    province: 'Madrid',
    postalCode: '28002',
    type: 'apartment',
    status: 'rented',
    bedrooms: 3,
    bathrooms: 2,
    area: 145,
    price: 2800,
    description: 'Espectacular ático con terraza de 40m² en el exclusivo barrio de Salamanca. Vistas panorámicas a la ciudad, acabados de lujo y parking incluido.',
    features: ['Terraza', 'Parking', 'Aire acondicionado', 'Calefacción central', 'Domótica', 'Vistas panorámicas'],
    images: ['/properties/atico-salamanca.jpg'],
    ownerId: 'owner-1',
    tenantId: 'tenant-1',
    createdAt: '2023-05-15',
    updatedAt: '2024-01-10'
  },
  {
    id: 'prop-2',
    name: 'Piso Reformado en Chamberí',
    address: 'Calle Ponzano 82, 3º B',
    city: 'Madrid',
    province: 'Madrid',
    postalCode: '28003',
    type: 'apartment',
    status: 'available',
    bedrooms: 2,
    bathrooms: 1,
    area: 85,
    price: 1500,
    description: 'Piso completamente reformado en el animado barrio de Chamberí. Cocina americana equipada, suelos de parquet y mucha luz natural.',
    features: ['Reformado', 'Cocina americana', 'Parquet', 'Luminoso', 'Ascensor', 'Trastero'],
    images: ['/properties/piso-chamberi.jpg'],
    ownerId: 'owner-1',
    createdAt: '2023-06-20',
    updatedAt: '2024-02-15'
  },
  {
    id: 'prop-3',
    name: 'Piso Moderno en El Born',
    address: 'Carrer del Rec 45, 2º 1ª',
    city: 'Barcelona',
    province: 'Barcelona',
    postalCode: '08003',
    type: 'apartment',
    status: 'rented',
    bedrooms: 2,
    bathrooms: 1,
    area: 75,
    price: 1800,
    description: 'Encantador piso en el corazón del barrio del Born. Techos con vigas de madera, diseño moderno y ubicación privilegiada cerca del mar.',
    features: ['Vigas de madera', 'Diseño moderno', 'Cerca del mar', 'Balcón', 'Aire acondicionado'],
    images: ['/properties/piso-born.jpg'],
    ownerId: 'owner-2',
    tenantId: 'tenant-2',
    createdAt: '2023-04-10',
    updatedAt: '2024-01-20'
  },
  {
    id: 'prop-4',
    name: 'Estudio en Les Corts',
    address: 'Carrer de Numància 120, Ático',
    city: 'Barcelona',
    province: 'Barcelona',
    postalCode: '08029',
    type: 'apartment',
    status: 'available',
    bedrooms: 1,
    bathrooms: 1,
    area: 45,
    price: 850,
    description: 'Estudio funcional en la zona residencial de Les Corts. Ideal para profesionales, muy bien comunicado con transporte público.',
    features: ['Funcional', 'Bien comunicado', 'Terraza comunitaria', 'Amueblado', 'WiFi incluido'],
    images: ['/properties/estudio-les-corts.jpg'],
    ownerId: 'owner-2',
    createdAt: '2023-07-05',
    updatedAt: '2024-02-01'
  },
  {
    id: 'prop-5',
    name: 'Casa con Jardín en Las Rozas',
    address: 'Urbanización Montecillo, 23',
    city: 'Las Rozas',
    province: 'Madrid',
    postalCode: '28232',
    type: 'house',
    status: 'rented',
    bedrooms: 4,
    bathrooms: 3,
    area: 220,
    price: 3500,
    description: 'Magnífica casa independiente con jardín privado y piscina. Zona residencial tranquila, cercana a colegios internacionales.',
    features: ['Jardín privado', 'Piscina', 'Garaje', 'Chimenea', '4 dormitorios', 'Cerca de colegios'],
    images: ['/properties/casa-rozas.jpg'],
    ownerId: 'owner-1',
    tenantId: 'tenant-3',
    createdAt: '2023-03-22',
    updatedAt: '2024-01-05'
  },
  {
    id: 'prop-6',
    name: 'Oficina en Distrito Financiero',
    address: 'Paseo de la Castellana 89, 12º',
    city: 'Madrid',
    province: 'Madrid',
    postalCode: '28046',
    type: 'office',
    status: 'rented',
    bedrooms: 0,
    bathrooms: 2,
    area: 180,
    price: 4200,
    description: 'Oficina de alto standing en el corazón financiero de Madrid. Espacios abiertos, salas de reuniones y recepción.',
    features: ['Espacio abierto', 'Salas de reuniones', 'Recepción', 'Parking', 'Seguridad 24h', 'Vistas'],
    images: ['/properties/oficina-castellana.jpg'],
    ownerId: 'owner-2',
    tenantId: 'tenant-4',
    createdAt: '2023-02-15',
    updatedAt: '2024-01-25'
  },
  {
    id: 'prop-7',
    name: 'Local Comercial en Centro Histórico',
    address: 'Plaza de la Virgen 8',
    city: 'Valencia',
    province: 'Valencia',
    postalCode: '46003',
    type: 'commercial',
    status: 'available',
    bedrooms: 0,
    bathrooms: 1,
    area: 120,
    price: 2200,
    description: 'Local comercial en zona de alto tránsito turístico. Ideal para restaurante o tienda, con terraza exterior autorizada.',
    features: ['Alto tránsito', 'Terraza autorizada', 'Salida de humos', 'Almacén', 'Zona turística'],
    images: ['/properties/local-valencia.jpg'],
    ownerId: 'owner-3',
    createdAt: '2023-08-10',
    updatedAt: '2024-02-20'
  },
  {
    id: 'prop-8',
    name: 'Apartamento en La Malvarrosa',
    address: 'Paseo Marítimo 156, 4º C',
    city: 'Valencia',
    province: 'Valencia',
    postalCode: '46011',
    type: 'apartment',
    status: 'maintenance',
    bedrooms: 2,
    bathrooms: 1,
    area: 70,
    price: 1200,
    description: 'Acogedor apartamento frente al mar en la playa de la Malvarrosa. En proceso de renovación, disponible en breve.',
    features: ['Frente al mar', 'Playa', 'Balcón', 'En renovación', 'Aire acondicionado'],
    images: ['/properties/apto-malvarrosa.jpg'],
    ownerId: 'owner-3',
    createdAt: '2023-09-01',
    updatedAt: '2024-02-28'
  },
  {
    id: 'prop-9',
    name: 'Nave Industrial en Polígono',
    address: 'Polígono Industrial Valsalada, Nave 45',
    city: 'Zaragoza',
    province: 'Zaragoza',
    postalCode: '50197',
    type: 'warehouse',
    status: 'available',
    bedrooms: 0,
    bathrooms: 2,
    area: 500,
    price: 3500,
    description: 'Nave industrial con oficinas integradas. Muelle de carga, altura libre de 8 metros y patio exterior.',
    features: ['Muelle de carga', 'Altura 8m', 'Oficinas', 'Patio exterior', 'Triple fase', 'Seguridad'],
    images: ['/properties/nave-zaragoza.jpg'],
    ownerId: 'owner-4',
    createdAt: '2023-10-05',
    updatedAt: '2024-01-30'
  },
  {
    id: 'prop-10',
    name: 'Ático Duplex en Casco Viejo',
    address: 'Calle de la Ronda 34, Ático',
    city: 'Bilbao',
    province: 'Vizcaya',
    postalCode: '48005',
    type: 'apartment',
    status: 'rented',
    bedrooms: 3,
    bathrooms: 2,
    area: 130,
    price: 1950,
    description: 'Espectacular dúplex en el encantador Casco Viejo de Bilbao. Terraza con vistas al Arenal, dos plantas con diseño contemporáneo.',
    features: ['Dúplex', 'Terraza', 'Vistas al Arenal', 'Diseño contemporáneo', '2 plantas', 'Ascensor'],
    images: ['/properties/duplex-bilbao.jpg'],
    ownerId: 'owner-4',
    tenantId: 'tenant-5',
    createdAt: '2023-11-15',
    updatedAt: '2024-02-10'
  }
];

// Sample Tenants
export const tenants: Tenant[] = [
  {
    id: 'tenant-1',
    name: 'Juan Martínez',
    email: 'juan.martinez@email.es',
    phone: '+34 656 789 012',
    propertyId: 'prop-1',
    contractStart: '2023-06-01',
    contractEnd: '2025-05-31',
    createdAt: '2023-05-20'
  },
  {
    id: 'tenant-2',
    name: 'Laura Sánchez',
    email: 'laura.sanchez@email.es',
    phone: '+34 667 890 123',
    propertyId: 'prop-3',
    contractStart: '2023-05-15',
    contractEnd: '2024-05-14',
    createdAt: '2023-05-01'
  },
  {
    id: 'tenant-3',
    name: 'Roberto García',
    email: 'roberto.garcia@email.es',
    phone: '+34 678 901 234',
    propertyId: 'prop-5',
    contractStart: '2023-04-01',
    contractEnd: '2025-03-31',
    createdAt: '2023-03-15'
  },
  {
    id: 'tenant-4',
    name: 'Ana Belén Torres',
    email: 'ana.torres@empresa.es',
    phone: '+34 689 012 345',
    propertyId: 'prop-6',
    contractStart: '2023-03-01',
    contractEnd: '2026-02-28',
    createdAt: '2023-02-15'
  },
  {
    id: 'tenant-5',
    name: 'Miguel Ángel Ruiz',
    email: 'miguel.ruiz@email.es',
    phone: '+34 690 123 456',
    propertyId: 'prop-10',
    contractStart: '2023-12-01',
    contractEnd: '2024-11-30',
    createdAt: '2023-11-20'
  }
];

// Sample Contracts
export const contracts: Contract[] = [
  {
    id: 'contract-1',
    propertyId: 'prop-1',
    tenantId: 'tenant-1',
    ownerId: 'owner-1',
    startDate: '2023-06-01',
    endDate: '2025-05-31',
    monthlyRent: 2800,
    deposit: 5600,
    status: 'active',
    fileName: 'contrato_atico_salamanca.pdf',
    fileSize: 245000,
    uploadDate: '2023-05-25',
    createdAt: '2023-05-20'
  },
  {
    id: 'contract-2',
    propertyId: 'prop-3',
    tenantId: 'tenant-2',
    ownerId: 'owner-2',
    startDate: '2023-05-15',
    endDate: '2024-05-14',
    monthlyRent: 1800,
    deposit: 3600,
    status: 'active',
    fileName: 'contrato_piso_born.pdf',
    fileSize: 198000,
    uploadDate: '2023-05-10',
    createdAt: '2023-05-01'
  },
  {
    id: 'contract-3',
    propertyId: 'prop-5',
    tenantId: 'tenant-3',
    ownerId: 'owner-1',
    startDate: '2023-04-01',
    endDate: '2025-03-31',
    monthlyRent: 3500,
    deposit: 7000,
    status: 'active',
    fileName: 'contrato_casa_rozas.pdf',
    fileSize: 312000,
    uploadDate: '2023-03-25',
    createdAt: '2023-03-15'
  },
  {
    id: 'contract-4',
    propertyId: 'prop-6',
    tenantId: 'tenant-4',
    ownerId: 'owner-2',
    startDate: '2023-03-01',
    endDate: '2026-02-28',
    monthlyRent: 4200,
    deposit: 12600,
    status: 'active',
    fileName: 'contrato_oficina_castellana.pdf',
    fileSize: 456000,
    uploadDate: '2023-02-20',
    createdAt: '2023-02-15'
  },
  {
    id: 'contract-5',
    propertyId: 'prop-10',
    tenantId: 'tenant-5',
    ownerId: 'owner-4',
    startDate: '2023-12-01',
    endDate: '2024-11-30',
    monthlyRent: 1950,
    deposit: 3900,
    status: 'active',
    fileName: 'contrato_duplex_bilbao.pdf',
    fileSize: 287000,
    uploadDate: '2023-11-25',
    createdAt: '2023-11-20'
  }
];

// Sample Service Requests
export const serviceRequests: ServiceRequest[] = [
  {
    id: 'request-1',
    propertyId: 'prop-1',
    tenantId: 'tenant-1',
    title: 'Fuga de agua en baño principal',
    description: 'Se ha detectado una fuga de agua debajo del lavabo del baño principal. El agua está filtrándose al suelo.',
    priority: 'urgent',
    status: 'in_progress',
    category: 'plumbing',
    createdAt: '2024-02-28',
    updatedAt: '2024-03-01'
  },
  {
    id: 'request-2',
    propertyId: 'prop-3',
    tenantId: 'tenant-2',
    title: 'Aire acondicionado no enfría',
    description: 'El aire acondicionado del salón ha dejado de enfriar adecuadamente. Solo expulsa aire templado.',
    priority: 'medium',
    status: 'pending',
    category: 'hvac',
    createdAt: '2024-03-01',
    updatedAt: '2024-03-01'
  },
  {
    id: 'request-3',
    propertyId: 'prop-5',
    tenantId: 'tenant-3',
    title: 'Puerta del garaje atascada',
    description: 'La puerta del garaje se queda atascada a mitad de camino y hace un ruido extraño.',
    priority: 'high',
    status: 'resolved',
    category: 'structural',
    createdAt: '2024-02-20',
    updatedAt: '2024-02-25',
    resolvedAt: '2024-02-25'
  },
  {
    id: 'request-4',
    propertyId: 'prop-6',
    tenantId: 'tenant-4',
    title: 'Luz intermitente en recepción',
    description: 'La luz del techo de la recepción parpadea constantemente, molestando al personal.',
    priority: 'low',
    status: 'pending',
    category: 'electrical',
    createdAt: '2024-02-27',
    updatedAt: '2024-02-27'
  },
  {
    id: 'request-5',
    propertyId: 'prop-10',
    tenantId: 'tenant-5',
    title: 'Frigorífico haciendo ruido',
    description: 'El frigorífico de la cocina hace un ruido muy fuerte cuando está en funcionamiento.',
    priority: 'medium',
    status: 'pending',
    category: 'appliance',
    createdAt: '2024-03-02',
    updatedAt: '2024-03-02'
  }
];

// Helper functions
export function getPropertyById(id: string): Property | undefined {
  return properties.find(p => p.id === id);
}

export function getOwnerById(id: string): Owner | undefined {
  return owners.find(o => o.id === id);
}

export function getTenantById(id: string): Tenant | undefined {
  return tenants.find(t => t.id === id);
}

export function getContractById(id: string): Contract | undefined {
  return contracts.find(c => c.id === id);
}

export function getServiceRequestById(id: string): ServiceRequest | undefined {
  return serviceRequests.find(r => r.id === id);
}

export function getPropertiesByOwner(ownerId: string): Property[] {
  return properties.filter(p => p.ownerId === ownerId);
}

export function getPropertiesByTenant(tenantId: string): Property | undefined {
  return properties.find(p => p.tenantId === tenantId);
}

export function getContractsByProperty(propertyId: string): Contract[] {
  return contracts.filter(c => c.propertyId === propertyId);
}

export function getServiceRequestsByProperty(propertyId: string): ServiceRequest[] {
  return serviceRequests.filter(r => r.propertyId === propertyId);
}

export function getServiceRequestsByTenant(tenantId: string): ServiceRequest[] {
  return serviceRequests.filter(r => r.tenantId === tenantId);
}

export function getContractByTenant(tenantId: string): Contract | undefined {
  return contracts.find(c => c.tenantId === tenantId);
}

// Dashboard KPIs
export function getDashboardKPIs(): {
  totalProperties: number;
  rentedProperties: number;
  availableProperties: number;
  maintenanceProperties: number;
  totalRevenue: number;
  activeContracts: number;
  pendingRequests: number;
  occupancyRate: number;
} {
  const totalProperties = properties.length;
  const rentedProperties = properties.filter(p => p.status === 'rented').length;
  const availableProperties = properties.filter(p => p.status === 'available').length;
  const maintenanceProperties = properties.filter(p => p.status === 'maintenance').length;
  
  const totalRevenue = properties
    .filter(p => p.status === 'rented')
    .reduce((sum, p) => sum + p.price, 0);
  
  const activeContracts = contracts.filter(c => c.status === 'active').length;
  const pendingRequests = serviceRequests.filter(r => r.status === 'pending' || r.status === 'in_progress').length;
  const occupancyRate = Math.round((rentedProperties / totalProperties) * 100);

  return {
    totalProperties,
    rentedProperties,
    availableProperties,
    maintenanceProperties,
    totalRevenue,
    activeContracts,
    pendingRequests,
    occupancyRate
  };
}
