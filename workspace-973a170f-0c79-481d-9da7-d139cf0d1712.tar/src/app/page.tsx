'use client';

import React, { useState } from 'react';
import { useAuthStore } from '@/store/auth-store';
import { useAppStore } from '@/store/app-store';
import { UserRole, Property, ServiceRequest, Contract } from '@/types';
import { 
  getPropertiesByOwner, 
  getPropertiesByTenant, 
  getOwnerById, 
  getTenantById,
  getServiceRequestsByTenant,
  getServiceRequestsByProperty,
  getContractByTenant,
  getDashboardKPIs
} from '@/lib/mock-data';

// Icons
import { 
  Building2, 
  Home, 
  FileText, 
  BarChart3, 
  Wrench, 
  LogOut,
  ChevronRight,
  Plus,
  Search,
  Filter,
  MapPin,
  Bed,
  Bath,
  Square,
  Euro,
  Calendar,
  User,
  Phone,
  Mail,
  AlertCircle,
  CheckCircle,
  Clock,
  Upload,
  Download,
  Eye,
  Edit,
  Trash2,
  X,
  AlertTriangle,
  Zap,
  Droplets,
  Wind,
  Settings,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Users,
  Package
} from 'lucide-react';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from '@/hooks/use-toast';

// ============ LOGIN PAGE ============
function LoginPage() {
  const login = useAuthStore((state) => state.login);
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);

  const roles = [
    {
      role: 'admin' as UserRole,
      title: 'Administrador',
      description: 'Acceso completo a todas las funciones del sistema',
      icon: Settings,
      features: ['Gestión de propiedades', 'Gestión de contratos', 'Informes y reportes', 'Control total']
    },
    {
      role: 'owner' as UserRole,
      title: 'Propietario',
      description: 'Vista de sus propiedades y contratos',
      icon: Building2,
      features: ['Ver propiedades', 'Consultar contratos', 'Estado de alquileres', 'Informes personales']
    },
    {
      role: 'tenant' as UserRole,
      title: 'Inquilino',
      description: 'Gestión de solicitudes de servicio',
      icon: Home,
      features: ['Ver propiedad', 'Solicitar servicios', 'Consultar contrato', 'Estado de solicitudes']
    }
  ];

  const handleLogin = () => {
    if (selectedRole) {
      login(selectedRole);
      toast({
        title: 'Sesión iniciada',
        description: `Bienvenido al sistema de gestión inmobiliaria`,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a365d] to-[#2d4a7c] flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <Building2 className="h-12 w-12 text-[#d69e2e]" />
            <h1 className="text-4xl font-bold text-white">InmoGest Pro</h1>
          </div>
          <p className="text-white/80 text-lg">Sistema de Gestión Inmobiliaria</p>
          <p className="text-white/60 mt-2">Seleccione su rol para acceder al sistema (Modo Demo)</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {roles.map((r) => (
            <Card 
              key={r.role}
              className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                selectedRole === r.role 
                  ? 'ring-2 ring-[#d69e2e] bg-[#1a365d]/5' 
                  : 'hover:shadow-xl'
              }`}
              onClick={() => setSelectedRole(r.role)}
            >
              <CardHeader className="text-center pb-2">
                <div className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-3 ${
                  selectedRole === r.role ? 'bg-[#d69e2e]' : 'bg-[#1a365d]'
                }`}>
                  <r.icon className="h-8 w-8 text-white" />
                </div>
                <CardTitle className="text-xl">{r.title}</CardTitle>
                <CardDescription>{r.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {r.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="h-4 w-4 text-[#38a169]" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button 
            size="lg" 
            className="bg-[#d69e2e] hover:bg-[#d69e2e]/90 text-white px-12 py-6 text-lg"
            disabled={!selectedRole}
            onClick={handleLogin}
          >
            Acceder al Sistema
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============ SIDEBAR ============
function Sidebar() {
  const { user, logout } = useAuthStore();
  const { currentView, setCurrentView, serviceRequests } = useAppStore();
  
  const adminMenuItems = [
    { id: 'dashboard', label: 'Panel de Control', icon: BarChart3 },
    { id: 'properties', label: 'Propiedades', icon: Building2 },
    { id: 'contracts', label: 'Contratos', icon: FileText },
    { id: 'reports', label: 'Informes', icon: BarChart3 },
    { id: 'service-requests', label: 'Solicitudes', icon: Wrench },
  ];

  const ownerMenuItems = [
    { id: 'dashboard', label: 'Panel de Control', icon: BarChart3 },
    { id: 'properties', label: 'Mis Propiedades', icon: Building2 },
    { id: 'contracts', label: 'Contratos', icon: FileText },
    { id: 'reports', label: 'Informes', icon: BarChart3 },
  ];

  const tenantMenuItems = [
    { id: 'dashboard', label: 'Mi Propiedad', icon: Home },
    { id: 'service-requests', label: 'Solicitudes de Servicio', icon: Wrench },
    { id: 'contracts', label: 'Mi Contrato', icon: FileText },
  ];

  const menuItems = user?.role === 'admin' ? adminMenuItems 
    : user?.role === 'owner' ? ownerMenuItems 
    : tenantMenuItems;

  const pendingRequests = serviceRequests.filter(r => r.status === 'pending' || r.status === 'in_progress').length;

  return (
    <aside className="w-64 bg-[#1a365d] min-h-screen flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <Building2 className="h-8 w-8 text-[#d69e2e]" />
          <span className="text-xl font-bold text-white">InmoGest Pro</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setCurrentView(item.id as typeof currentView)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  currentView === item.id 
                    ? 'bg-[#d69e2e] text-white' 
                    : 'text-white/70 hover:bg-white/10 hover:text-white'
                }`}
              >
                <item.icon className="h-5 w-5" />
                <span className="flex-1 text-left">{item.label}</span>
                {item.id === 'service-requests' && pendingRequests > 0 && (
                  <Badge className="bg-red-500 text-white">{pendingRequests}</Badge>
                )}
                {currentView === item.id && <ChevronRight className="h-4 w-4" />}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3 mb-4">
          <Avatar className="h-10 w-10 bg-[#d69e2e]">
            <AvatarFallback className="text-white font-semibold">
              {user?.avatar}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-white font-medium truncate">{user?.name}</p>
            <p className="text-white/60 text-sm capitalize">{user?.role === 'admin' ? 'Administrador' : user?.role === 'owner' ? 'Propietario' : 'Inquilino'}</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="w-full border-white/20 text-white hover:bg-white/10"
          onClick={logout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Cerrar Sesión
        </Button>
      </div>
    </aside>
  );
}

// ============ DASHBOARD - ADMIN ============
function AdminDashboard() {
  const kpis = getDashboardKPIs();
  const { properties, serviceRequests, setCurrentView } = useAppStore();

  const kpiCards = [
    { 
      title: 'Total Propiedades', 
      value: kpis.totalProperties, 
      icon: Building2, 
      color: 'bg-[#1a365d]',
      change: '+2 este mes'
    },
    { 
      title: 'Propiedades Alquiladas', 
      value: kpis.rentedProperties, 
      icon: Home, 
      color: 'bg-[#38a169]',
      change: `${kpis.occupancyRate}% ocupación`
    },
    { 
      title: 'Disponibles', 
      value: kpis.availableProperties, 
      icon: Package, 
      color: 'bg-[#d69e2e]',
      change: 'En el mercado'
    },
    { 
      title: 'Ingresos Mensuales', 
      value: `${kpis.totalRevenue.toLocaleString('es-ES')}€`, 
      icon: Euro, 
      color: 'bg-[#38a169]',
      change: '+5.2% vs mes anterior'
    },
    { 
      title: 'Contratos Activos', 
      value: kpis.activeContracts, 
      icon: FileText, 
      color: 'bg-[#1a365d]',
      change: 'Vigentes'
    },
    { 
      title: 'Solicitudes Pendientes', 
      value: kpis.pendingRequests, 
      icon: Wrench, 
      color: 'bg-red-500',
      change: 'Requieren atención'
    }
  ];

  const recentProperties = properties.slice(0, 4);
  const recentRequests = serviceRequests.slice(0, 4);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Panel de Control</h1>
          <p className="text-muted-foreground">Resumen general de la actividad inmobiliaria</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-[#38a169] border-[#38a169]">
            <TrendingUp className="h-3 w-3 mr-1" />
            +12% este mes
          </Badge>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {kpiCards.map((kpi, i) => (
          <Card key={i} className="overflow-hidden">
            <div className={`${kpi.color} p-4`}>
              <kpi.icon className="h-6 w-6 text-white" />
            </div>
            <CardContent className="pt-4">
              <p className="text-sm text-muted-foreground">{kpi.title}</p>
              <p className="text-2xl font-bold">{kpi.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{kpi.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts and Tables */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Properties */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Propiedades Recientes</CardTitle>
              <CardDescription>Últimas propiedades añadidas</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => setCurrentView('properties')}>
              Ver todas
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="max-h-80 overflow-y-auto scrollbar-thin">
            <div className="space-y-4">
              {recentProperties.map((property) => (
                <div key={property.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="h-12 w-12 rounded-lg bg-[#1a365d] flex items-center justify-center">
                    <Building2 className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{property.name}</p>
                    <p className="text-sm text-muted-foreground truncate">{property.city}, {property.province}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-[#38a169]">{property.price.toLocaleString('es-ES')}€</p>
                    <Badge variant={property.status === 'rented' ? 'default' : property.status === 'available' ? 'secondary' : 'destructive'}>
                      {property.status === 'rented' ? 'Alquilado' : property.status === 'available' ? 'Disponible' : 'Mantenimiento'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Service Requests */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Solicitudes de Servicio</CardTitle>
              <CardDescription>Últimas solicitudes recibidas</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => setCurrentView('service-requests')}>
              Ver todas
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="max-h-80 overflow-y-auto scrollbar-thin">
            <div className="space-y-4">
              {recentRequests.map((request) => (
                <div key={request.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                    request.priority === 'urgent' ? 'bg-red-100' :
                    request.priority === 'high' ? 'bg-orange-100' :
                    request.priority === 'medium' ? 'bg-yellow-100' : 'bg-green-100'
                  }`}>
                    <AlertCircle className={`h-5 w-5 ${
                      request.priority === 'urgent' ? 'text-red-600' :
                      request.priority === 'high' ? 'text-orange-600' :
                      request.priority === 'medium' ? 'text-yellow-600' : 'text-green-600'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{request.title}</p>
                    <p className="text-sm text-muted-foreground capitalize">{request.category}</p>
                  </div>
                  <Badge variant={
                    request.status === 'pending' ? 'outline' :
                    request.status === 'in_progress' ? 'default' :
                    request.status === 'resolved' ? 'secondary' : 'destructive'
                  }>
                    {request.status === 'pending' ? 'Pendiente' :
                     request.status === 'in_progress' ? 'En Progreso' :
                     request.status === 'resolved' ? 'Resuelto' : 'Cerrado'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Occupancy Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Tasa de Ocupación por Tipo</CardTitle>
          <CardDescription>Distribución de propiedades por tipo y estado</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {['apartment', 'house', 'office', 'commercial', 'warehouse'].map((type) => {
              const typeProperties = properties.filter(p => p.type === type);
              const rented = typeProperties.filter(p => p.status === 'rented').length;
              const total = typeProperties.length;
              const percentage = total > 0 ? Math.round((rented / total) * 100) : 0;
              
              return (
                <div key={type} className="text-center">
                  <div className="relative w-20 h-20 mx-auto mb-2">
                    <svg className="w-20 h-20 transform -rotate-90">
                      <circle cx="40" cy="40" r="36" stroke="#e5e7eb" strokeWidth="8" fill="none" />
                      <circle 
                        cx="40" 
                        cy="40" 
                        r="36" 
                        stroke="#38a169" 
                        strokeWidth="8" 
                        fill="none"
                        strokeDasharray={`${percentage * 2.26} 226`}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-lg font-bold">{percentage}%</span>
                    </div>
                  </div>
                  <p className="font-medium capitalize">{type === 'apartment' ? 'Apartamento' : type === 'house' ? 'Casa' : type === 'office' ? 'Oficina' : type === 'commercial' ? 'Comercial' : 'Nave'}</p>
                  <p className="text-sm text-muted-foreground">{rented}/{total} alquilados</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============ DASHBOARD - OWNER ============
function OwnerDashboard() {
  const { user } = useAuthStore();
  const { properties, contracts, setCurrentView } = useAppStore();
  
  const ownerProperties = getPropertiesByOwner('owner-1'); // Demo: María Rodríguez
  const totalRevenue = ownerProperties
    .filter(p => p.status === 'rented')
    .reduce((sum, p) => sum + p.price, 0);
  const activeContracts = ownerProperties.filter(p => p.status === 'rented').length;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Bienvenido, {user?.name}</h1>
          <p className="text-muted-foreground">Resumen de sus propiedades</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-[#1a365d] flex items-center justify-center">
                <Building2 className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Mis Propiedades</p>
                <p className="text-2xl font-bold">{ownerProperties.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-[#38a169] flex items-center justify-center">
                <Home className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Alquiladas</p>
                <p className="text-2xl font-bold">{activeContracts}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-[#d69e2e] flex items-center justify-center">
                <Euro className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Ingresos Mensuales</p>
                <p className="text-2xl font-bold">{totalRevenue.toLocaleString('es-ES')}€</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-[#1a365d] flex items-center justify-center">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Contratos Activos</p>
                <p className="text-2xl font-bold">{activeContracts}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Properties List */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Mis Propiedades</CardTitle>
            <CardDescription>Lista de todas sus propiedades registradas</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => setCurrentView('properties')}>
            Ver detalles
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </CardHeader>
        <CardContent className="max-h-96 overflow-y-auto scrollbar-thin">
          <div className="space-y-4">
            {ownerProperties.map((property) => (
              <div key={property.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                <div className="h-16 w-16 rounded-lg bg-[#1a365d] flex items-center justify-center">
                  <Building2 className="h-8 w-8 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{property.name}</p>
                  <p className="text-sm text-muted-foreground truncate">{property.address}, {property.city}</p>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Bed className="h-3 w-3" /> {property.bedrooms}
                    </span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Bath className="h-3 w-3" /> {property.bathrooms}
                    </span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Square className="h-3 w-3" /> {property.area}m²
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg text-[#38a169]">{property.price.toLocaleString('es-ES')}€/mes</p>
                  <Badge variant={property.status === 'rented' ? 'default' : property.status === 'available' ? 'secondary' : 'destructive'}>
                    {property.status === 'rented' ? 'Alquilado' : property.status === 'available' ? 'Disponible' : 'Mantenimiento'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============ DASHBOARD - TENANT ============
function TenantDashboard() {
  const { user } = useAuthStore();
  const { serviceRequests, setCurrentView } = useAppStore();
  
  // Demo: Juan Martínez is tenant-1
  const property = getPropertiesByTenant('tenant-1');
  const tenantRequests = getServiceRequestsByTenant('tenant-1');
  const contract = getContractByTenant('tenant-1');

  if (!property) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6 text-center">
            <Home className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No tiene ninguna propiedad asignada</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Bienvenido, {user?.name}</h1>
          <p className="text-muted-foreground">Información de su propiedad y solicitudes</p>
        </div>
      </div>

      {/* Property Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Home className="h-5 w-5 text-[#1a365d]" />
            Mi Propiedad
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-lg mb-2">{property.name}</h3>
              <p className="text-muted-foreground flex items-center gap-2 mb-4">
                <MapPin className="h-4 w-4" />
                {property.address}, {property.city}, {property.province}
              </p>
              
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-muted rounded-lg">
                  <Bed className="h-5 w-5 mx-auto mb-1 text-[#1a365d]" />
                  <p className="font-semibold">{property.bedrooms}</p>
                  <p className="text-xs text-muted-foreground">Habitaciones</p>
                </div>
                <div className="text-center p-3 bg-muted rounded-lg">
                  <Bath className="h-5 w-5 mx-auto mb-1 text-[#1a365d]" />
                  <p className="font-semibold">{property.bathrooms}</p>
                  <p className="text-xs text-muted-foreground">Baños</p>
                </div>
                <div className="text-center p-3 bg-muted rounded-lg">
                  <Square className="h-5 w-5 mx-auto mb-1 text-[#1a365d]" />
                  <p className="font-semibold">{property.area}m²</p>
                  <p className="text-xs text-muted-foreground">Superficie</p>
                </div>
              </div>

              <p className="text-sm text-muted-foreground">{property.description}</p>
            </div>

            <div>
              <h4 className="font-semibold mb-3">Características</h4>
              <div className="flex flex-wrap gap-2">
                {property.features.map((feature, i) => (
                  <Badge key={i} variant="secondary">{feature}</Badge>
                ))}
              </div>

              {contract && (
                <div className="mt-4 p-4 bg-[#1a365d]/5 rounded-lg">
                  <h4 className="font-semibold mb-2">Información del Contrato</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Renta mensual:</span>
                      <span className="font-semibold text-[#38a169]">{contract.monthlyRent.toLocaleString('es-ES')}€</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fianza:</span>
                      <span className="font-semibold">{contract.deposit.toLocaleString('es-ES')}€</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Inicio:</span>
                      <span>{new Date(contract.startDate).toLocaleDateString('es-ES')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fin:</span>
                      <span>{new Date(contract.endDate).toLocaleDateString('es-ES')}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Service Requests */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Mis Solicitudes de Servicio</CardTitle>
              <CardDescription>Estado de sus solicitudes</CardDescription>
            </div>
            <Button onClick={() => setCurrentView('service-form')}>
              <Plus className="h-4 w-4 mr-2" />
              Nueva Solicitud
            </Button>
          </CardHeader>
          <CardContent className="max-h-64 overflow-y-auto scrollbar-thin">
            {tenantRequests.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Wrench className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No tiene solicitudes de servicio</p>
              </div>
            ) : (
              <div className="space-y-3">
                {tenantRequests.map((request) => (
                  <div key={request.id} className="flex items-center gap-3 p-3 border rounded-lg">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      request.priority === 'urgent' ? 'bg-red-100' :
                      request.priority === 'high' ? 'bg-orange-100' : 'bg-yellow-100'
                    }`}>
                      <AlertCircle className={`h-4 w-4 ${
                        request.priority === 'urgent' ? 'text-red-600' :
                        request.priority === 'high' ? 'text-orange-600' : 'text-yellow-600'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{request.title}</p>
                      <p className="text-xs text-muted-foreground">{new Date(request.createdAt).toLocaleDateString('es-ES')}</p>
                    </div>
                    <Badge variant={
                      request.status === 'pending' ? 'outline' :
                      request.status === 'in_progress' ? 'default' : 'secondary'
                    }>
                      {request.status === 'pending' ? 'Pendiente' :
                       request.status === 'in_progress' ? 'En Progreso' : 'Resuelto'}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start" variant="outline" onClick={() => setCurrentView('service-form')}>
              <Wrench className="h-4 w-4 mr-2" />
              Reportar Incidencia
            </Button>
            <Button className="w-full justify-start" variant="outline" onClick={() => setCurrentView('contracts')}>
              <FileText className="h-4 w-4 mr-2" />
              Ver Mi Contrato
            </Button>
            <Button className="w-full justify-start" variant="outline">
              <Phone className="h-4 w-4 mr-2" />
              Contactar Propietario
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// ============ PROPERTY LIST ============
function PropertyList() {
  const { user } = useAuthStore();
  const { properties, currentView, setCurrentView, setSelectedPropertyId } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Filter properties based on role
  const filteredProperties = properties.filter((p) => {
    if (user?.role === 'owner') {
      // Demo: María Rodríguez owns properties with ownerId 'owner-1'
      if (p.ownerId !== 'owner-1') return false;
    } else if (user?.role === 'tenant') {
      // Demo: Juan Martínez rents property prop-1
      if (p.tenantId !== 'tenant-1') return false;
    }

    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    const matchesType = typeFilter === 'all' || p.type === typeFilter;

    return matchesSearch && matchesStatus && matchesType;
  });

  const handleViewProperty = (id: string) => {
    setSelectedPropertyId(id);
    setCurrentView('property-detail');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">
            {user?.role === 'owner' ? 'Mis Propiedades' : user?.role === 'tenant' ? 'Mi Propiedad' : 'Gestión de Propiedades'}
          </h1>
          <p className="text-muted-foreground">
            {user?.role === 'admin' ? 'Administra todas las propiedades del sistema' : 'Vista de propiedades asignadas'}
          </p>
        </div>
        {user?.role === 'admin' && (
          <Button onClick={() => setCurrentView('property-form')}>
            <Plus className="h-4 w-4 mr-2" />
            Nueva Propiedad
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por nombre, dirección o ciudad..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            <SelectItem value="rented">Alquilado</SelectItem>
            <SelectItem value="available">Disponible</SelectItem>
            <SelectItem value="maintenance">Mantenimiento</SelectItem>
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los tipos</SelectItem>
            <SelectItem value="apartment">Apartamento</SelectItem>
            <SelectItem value="house">Casa</SelectItem>
            <SelectItem value="office">Oficina</SelectItem>
            <SelectItem value="commercial">Comercial</SelectItem>
            <SelectItem value="warehouse">Nave Industrial</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Properties Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProperties.map((property) => (
          <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-40 bg-gradient-to-br from-[#1a365d] to-[#2d4a7c] flex items-center justify-center">
              <Building2 className="h-16 w-16 text-white/50" />
            </div>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{property.name}</CardTitle>
                  <CardDescription className="flex items-center gap-1 mt-1">
                    <MapPin className="h-3 w-3" />
                    {property.city}, {property.province}
                  </CardDescription>
                </div>
                <Badge variant={
                  property.status === 'rented' ? 'default' :
                  property.status === 'available' ? 'secondary' : 'destructive'
                }>
                  {property.status === 'rented' ? 'Alquilado' :
                   property.status === 'available' ? 'Disponible' : 'Mantenimiento'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1">
                  <Bed className="h-4 w-4" /> {property.bedrooms}
                </span>
                <span className="flex items-center gap-1">
                  <Bath className="h-4 w-4" /> {property.bathrooms}
                </span>
                <span className="flex items-center gap-1">
                  <Square className="h-4 w-4" /> {property.area}m²
                </span>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-xl font-bold text-[#38a169]">{property.price.toLocaleString('es-ES')}€<span className="text-sm font-normal text-muted-foreground">/mes</span></p>
                <Button size="sm" variant="outline" onClick={() => handleViewProperty(property.id)}>
                  <Eye className="h-4 w-4 mr-1" />
                  Ver
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProperties.length === 0 && (
        <Card>
          <CardContent className="pt-6 text-center">
            <Building2 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No se encontraron propiedades con los filtros seleccionados</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============ PROPERTY DETAIL ============
function PropertyDetail() {
  const { user } = useAuthStore();
  const { properties, serviceRequests, selectedPropertyId, setCurrentView, deleteProperty } = useAppStore();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const property = properties.find(p => p.id === selectedPropertyId);
  const propertyRequests = selectedPropertyId ? getServiceRequestsByProperty(selectedPropertyId) : [];
  const owner = property ? getOwnerById(property.ownerId) : null;
  const tenant = property?.tenantId ? getTenantById(property.tenantId) : null;

  if (!property) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6 text-center">
            <Building2 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Propiedad no encontrada</p>
            <Button className="mt-4" onClick={() => setCurrentView('properties')}>Volver a Propiedades</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleDelete = () => {
    deleteProperty(property.id);
    setShowDeleteDialog(false);
    setCurrentView('properties');
    toast({
      title: 'Propiedad eliminada',
      description: 'La propiedad ha sido eliminada correctamente',
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => setCurrentView('properties')}>
            <ChevronRight className="h-4 w-4 rotate-180" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-[#1a365d]">{property.name}</h1>
            <p className="text-muted-foreground flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              {property.address}, {property.city}, {property.province} {property.postalCode}
            </p>
          </div>
        </div>
        {user?.role === 'admin' && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setCurrentView('property-form')}>
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </Button>
            <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Eliminar
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>¿Está seguro?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción no se puede deshacer. La propiedad será eliminada permanentemente del sistema.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Eliminar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Image Placeholder */}
          <Card className="overflow-hidden">
            <div className="h-64 bg-gradient-to-br from-[#1a365d] to-[#2d4a7c] flex items-center justify-center">
              <Building2 className="h-24 w-24 text-white/30" />
            </div>
          </Card>

          {/* Property Details */}
          <Card>
            <CardHeader>
              <CardTitle>Detalles de la Propiedad</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Bed className="h-6 w-6 mx-auto mb-2 text-[#1a365d]" />
                  <p className="text-2xl font-bold">{property.bedrooms}</p>
                  <p className="text-sm text-muted-foreground">Habitaciones</p>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Bath className="h-6 w-6 mx-auto mb-2 text-[#1a365d]" />
                  <p className="text-2xl font-bold">{property.bathrooms}</p>
                  <p className="text-sm text-muted-foreground">Baños</p>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Square className="h-6 w-6 mx-auto mb-2 text-[#1a365d]" />
                  <p className="text-2xl font-bold">{property.area}</p>
                  <p className="text-sm text-muted-foreground">m²</p>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <Euro className="h-6 w-6 mx-auto mb-2 text-[#38a169]" />
                  <p className="text-2xl font-bold">{property.price.toLocaleString('es-ES')}</p>
                  <p className="text-sm text-muted-foreground">€/mes</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Descripción</h4>
                  <p className="text-muted-foreground">{property.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Características</h4>
                  <div className="flex flex-wrap gap-2">
                    {property.features.map((feature, i) => (
                      <Badge key={i} variant="secondary">{feature}</Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Tipo</h4>
                  <Badge className={
                    property.type === 'apartment' ? 'bg-[#1a365d]' :
                    property.type === 'house' ? 'bg-[#38a169]' :
                    property.type === 'office' ? 'bg-[#d69e2e]' :
                    'bg-gray-600'
                  }>
                    {property.type === 'apartment' ? 'Apartamento' :
                     property.type === 'house' ? 'Casa' :
                     property.type === 'office' ? 'Oficina' :
                     property.type === 'commercial' ? 'Local Comercial' : 'Nave Industrial'}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Service Requests */}
          {user?.role === 'admin' && (
            <Card>
              <CardHeader>
                <CardTitle>Solicitudes de Servicio</CardTitle>
                <CardDescription>Incidencias reportadas para esta propiedad</CardDescription>
              </CardHeader>
              <CardContent className="max-h-64 overflow-y-auto scrollbar-thin">
                {propertyRequests.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Wrench className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No hay solicitudes de servicio</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {propertyRequests.map((request) => (
                      <div key={request.id} className="flex items-center gap-3 p-3 border rounded-lg">
                        <AlertCircle className={`h-5 w-5 ${
                          request.priority === 'urgent' ? 'text-red-500' :
                          request.priority === 'high' ? 'text-orange-500' : 'text-yellow-500'
                        }`} />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{request.title}</p>
                          <p className="text-xs text-muted-foreground">{new Date(request.createdAt).toLocaleDateString('es-ES')}</p>
                        </div>
                        <Badge variant={
                          request.status === 'pending' ? 'outline' :
                          request.status === 'in_progress' ? 'default' : 'secondary'
                        }>
                          {request.status === 'pending' ? 'Pendiente' :
                           request.status === 'in_progress' ? 'En Progreso' : 'Resuelto'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status Card */}
          <Card>
            <CardHeader>
              <CardTitle>Estado Actual</CardTitle>
            </CardHeader>
            <CardContent>
              <Badge className={`text-lg py-2 px-4 ${
                property.status === 'rented' ? 'bg-[#38a169]' :
                property.status === 'available' ? 'bg-[#d69e2e]' : 'bg-red-500'
              }`}>
                {property.status === 'rented' ? 'Alquilado' :
                 property.status === 'available' ? 'Disponible' : 'En Mantenimiento'}
              </Badge>
              <div className="mt-4 text-sm text-muted-foreground">
                <p>Creado: {new Date(property.createdAt).toLocaleDateString('es-ES')}</p>
                <p>Actualizado: {new Date(property.updatedAt).toLocaleDateString('es-ES')}</p>
              </div>
            </CardContent>
          </Card>

          {/* Owner Info */}
          {owner && (
            <Card>
              <CardHeader>
                <CardTitle>Propietario</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10 bg-[#1a365d]">
                    <AvatarFallback className="text-white">
                      {owner.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{owner.name}</p>
                    <p className="text-sm text-muted-foreground">Propietario</p>
                  </div>
                </div>
                <Separator />
                <div className="space-y-2 text-sm">
                  <p className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    {owner.email}
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    {owner.phone}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Tenant Info */}
          {tenant && (
            <Card>
              <CardHeader>
                <CardTitle>Inquilino Actual</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10 bg-[#38a169]">
                    <AvatarFallback className="text-white">
                      {tenant.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{tenant.name}</p>
                    <p className="text-sm text-muted-foreground">Inquilino</p>
                  </div>
                </div>
                <Separator />
                <div className="space-y-2 text-sm">
                  <p className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    {tenant.email}
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    {tenant.phone}
                  </p>
                  <p className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    {new Date(tenant.contractStart).toLocaleDateString('es-ES')} - {new Date(tenant.contractEnd).toLocaleDateString('es-ES')}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

// ============ PROPERTY FORM ============
function PropertyForm() {
  const { selectedPropertyId, properties, setCurrentView, addProperty, updateProperty } = useAppStore();
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    province: '',
    postalCode: '',
    type: 'apartment',
    status: 'available',
    bedrooms: '1',
    bathrooms: '1',
    area: '',
    price: '',
    description: '',
    features: ''
  });

  const existingProperty = selectedPropertyId ? properties.find(p => p.id === selectedPropertyId) : null;

  React.useEffect(() => {
    if (existingProperty) {
      setFormData({
        name: existingProperty.name,
        address: existingProperty.address,
        city: existingProperty.city,
        province: existingProperty.province,
        postalCode: existingProperty.postalCode,
        type: existingProperty.type,
        status: existingProperty.status,
        bedrooms: existingProperty.bedrooms.toString(),
        bathrooms: existingProperty.bathrooms.toString(),
        area: existingProperty.area.toString(),
        price: existingProperty.price.toString(),
        description: existingProperty.description,
        features: existingProperty.features.join(', ')
      });
    }
  }, [existingProperty]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const propertyData: Property = {
      id: existingProperty?.id || `prop-${Date.now()}`,
      name: formData.name,
      address: formData.address,
      city: formData.city,
      province: formData.province,
      postalCode: formData.postalCode,
      type: formData.type as Property['type'],
      status: formData.status as Property['status'],
      bedrooms: parseInt(formData.bedrooms),
      bathrooms: parseInt(formData.bathrooms),
      area: parseInt(formData.area),
      price: parseInt(formData.price),
      description: formData.description,
      features: formData.features.split(',').map(f => f.trim()).filter(Boolean),
      images: [],
      ownerId: existingProperty?.ownerId || 'owner-1',
      tenantId: existingProperty?.tenantId,
      createdAt: existingProperty?.createdAt || new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };

    if (existingProperty) {
      updateProperty(existingProperty.id, propertyData);
      toast({
        title: 'Propiedad actualizada',
        description: 'Los cambios han sido guardados correctamente',
      });
    } else {
      addProperty(propertyData);
      toast({
        title: 'Propiedad creada',
        description: 'La nueva propiedad ha sido añadida al sistema',
      });
    }

    setCurrentView('properties');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => setCurrentView('properties')}>
          <ChevronRight className="h-4 w-4 rotate-180" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">
            {existingProperty ? 'Editar Propiedad' : 'Nueva Propiedad'}
          </h1>
          <p className="text-muted-foreground">
            {existingProperty ? 'Modifique los datos de la propiedad' : 'Complete los datos para registrar una nueva propiedad'}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Información General</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre de la Propiedad *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ej: Ático con Terraza en Salamanca"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Propiedad *</Label>
                <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="apartment">Apartamento</SelectItem>
                    <SelectItem value="house">Casa</SelectItem>
                    <SelectItem value="office">Oficina</SelectItem>
                    <SelectItem value="commercial">Local Comercial</SelectItem>
                    <SelectItem value="warehouse">Nave Industrial</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Dirección *</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Ej: Calle Serrano 156, 6º D"
                required
              />
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">Ciudad *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="Madrid"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="province">Provincia *</Label>
                <Input
                  id="province"
                  value={formData.province}
                  onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                  placeholder="Madrid"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="postalCode">Código Postal *</Label>
                <Input
                  id="postalCode"
                  value={formData.postalCode}
                  onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                  placeholder="28002"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Estado *</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Disponible</SelectItem>
                  <SelectItem value="rented">Alquilado</SelectItem>
                  <SelectItem value="maintenance">En Mantenimiento</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Características</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bedrooms">Habitaciones</Label>
                <Input
                  id="bedrooms"
                  type="number"
                  min="0"
                  value={formData.bedrooms}
                  onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bathrooms">Baños</Label>
                <Input
                  id="bathrooms"
                  type="number"
                  min="0"
                  value={formData.bathrooms}
                  onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="area">Superficie (m²) *</Label>
                <Input
                  id="area"
                  type="number"
                  min="1"
                  value={formData.area}
                  onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                  placeholder="120"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Precio (€/mes) *</Label>
                <Input
                  id="price"
                  type="number"
                  min="1"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="1500"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Descripción detallada de la propiedad..."
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="features">Características Adicionales</Label>
              <Input
                id="features"
                value={formData.features}
                onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                placeholder="Terraza, Parking, Aire acondicionado (separados por comas)"
              />
              <p className="text-xs text-muted-foreground">Separe las características con comas</p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4 mt-6">
          <Button type="button" variant="outline" onClick={() => setCurrentView('properties')}>
            Cancelar
          </Button>
          <Button type="submit" className="bg-[#1a365d] hover:bg-[#1a365d]/90">
            {existingProperty ? 'Guardar Cambios' : 'Crear Propiedad'}
          </Button>
        </div>
      </form>
    </div>
  );
}

// ============ CONTRACTS ============
function ContractsSection() {
  const { user } = useAuthStore();
  const { contracts, properties } = useAppStore();
  const [showUploadDialog, setShowUploadDialog] = useState(false);

  // Filter contracts based on role
  const filteredContracts = contracts.filter((c) => {
    if (user?.role === 'owner') {
      // Demo: María Rodríguez owns properties with ownerId 'owner-1'
      const ownerProperties = properties.filter(p => p.ownerId === 'owner-1').map(p => p.id);
      return ownerProperties.includes(c.propertyId);
    } else if (user?.role === 'tenant') {
      return c.tenantId === 'tenant-1';
    }
    return true;
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Gestión de Contratos</h1>
          <p className="text-muted-foreground">
            {user?.role === 'admin' ? 'Administra todos los contratos del sistema' : 'Vista de contratos asociados'}
          </p>
        </div>
        {user?.role === 'admin' && (
          <Button onClick={() => setShowUploadDialog(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Subir Contrato
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-[#38a169] flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Contratos Activos</p>
                <p className="text-2xl font-bold">{filteredContracts.filter(c => c.status === 'active').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-[#d69e2e] flex items-center justify-center">
                <Clock className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Próximos a Vencer</p>
                <p className="text-2xl font-bold">2</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-[#1a365d] flex items-center justify-center">
                <Euro className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Ingresos Mensuales</p>
                <p className="text-2xl font-bold">{filteredContracts.filter(c => c.status === 'active').reduce((sum, c) => sum + c.monthlyRent, 0).toLocaleString('es-ES')}€</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Contratos</p>
                <p className="text-2xl font-bold">{filteredContracts.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contracts Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Contratos</CardTitle>
        </CardHeader>
        <CardContent className="max-h-96 overflow-y-auto scrollbar-thin">
          <div className="space-y-4">
            {filteredContracts.map((contract) => {
              const property = properties.find(p => p.id === contract.propertyId);
              const tenant = getTenantById(contract.tenantId);

              return (
                <div key={contract.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="h-12 w-12 rounded-lg bg-[#1a365d] flex items-center justify-center">
                    <FileText className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{property?.name || 'Propiedad desconocida'}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Inquilino: {tenant?.name}</span>
                      <span>•</span>
                      <span>{new Date(contract.startDate).toLocaleDateString('es-ES')} - {new Date(contract.endDate).toLocaleDateString('es-ES')}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-[#38a169]">{contract.monthlyRent.toLocaleString('es-ES')}€/mes</p>
                    <Badge variant={contract.status === 'active' ? 'default' : 'secondary'}>
                      {contract.status === 'active' ? 'Activo' : contract.status === 'expired' ? 'Vencido' : 'Terminado'}
                    </Badge>
                  </div>
                  {user?.role === 'admin' && contract.fileName && (
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4 mr-1" />
                      Descargar
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Subir Nuevo Contrato</DialogTitle>
            <DialogDescription>
              Seleccione un archivo PDF del contrato para subir al sistema.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <Upload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-sm text-muted-foreground mb-2">Arrastre el archivo aquí o haga clic para seleccionar</p>
              <Input type="file" accept=".pdf" className="mx-auto max-w-xs" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowUploadDialog(false)}>Cancelar</Button>
              <Button onClick={() => {
                setShowUploadDialog(false);
                toast({ title: 'Contrato subido', description: 'El contrato ha sido subido correctamente' });
              }}>Subir Contrato</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============ REPORTS ============
function ReportsSection() {
  const { properties, contracts, serviceRequests } = useAppStore();
  const [reportType, setReportType] = useState('occupancy');
  const kpis = getDashboardKPIs();

  const reports = [
    { id: 'occupancy', title: 'Informe de Ocupación', icon: Home, description: 'Análisis detallado de la tasa de ocupación' },
    { id: 'revenue', title: 'Informe de Ingresos', icon: Euro, description: 'Resumen de ingresos por alquiler' },
    { id: 'maintenance', title: 'Informe de Mantenimiento', icon: Wrench, description: 'Estado de solicitudes de servicio' },
    { id: 'contracts', title: 'Informe de Contratos', icon: FileText, description: 'Estado y vencimientos de contratos' }
  ];

  const generateReport = () => {
    toast({
      title: 'Informe Generado',
      description: 'El informe ha sido generado y está listo para descargar',
    });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Informes y Reportes</h1>
          <p className="text-muted-foreground">Genera informes detallados sobre el estado de las propiedades</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-[#1a365d]">{kpis.occupancyRate}%</p>
              <p className="text-sm text-muted-foreground">Tasa de Ocupación</p>
              <Progress value={kpis.occupancyRate} className="mt-2" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-[#38a169]">{kpis.totalRevenue.toLocaleString('es-ES')}€</p>
              <p className="text-sm text-muted-foreground">Ingresos Mensuales</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-[#d69e2e]">{kpis.activeContracts}</p>
              <p className="text-sm text-muted-foreground">Contratos Activos</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-red-500">{kpis.pendingRequests}</p>
              <p className="text-sm text-muted-foreground">Solicitudes Pendientes</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Types */}
      <div className="grid md:grid-cols-2 gap-6">
        {reports.map((report) => (
          <Card key={report.id} className="cursor-pointer hover:border-[#1a365d] transition-colors" onClick={() => setReportType(report.id)}>
            <CardHeader className="flex flex-row items-center gap-4">
              <div className="h-12 w-12 rounded-lg bg-[#1a365d] flex items-center justify-center">
                <report.icon className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1">
                <CardTitle className="text-lg">{report.title}</CardTitle>
                <CardDescription>{report.description}</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={(e) => {
                e.stopPropagation();
                generateReport();
              }}>
                <Download className="h-4 w-4 mr-1" />
                Generar
              </Button>
            </CardHeader>
          </Card>
        ))}
      </div>

      {/* Sample Report Preview */}
      <Card>
        <CardHeader>
          <CardTitle>Vista Previa del Informe: {reports.find(r => r.id === reportType)?.title}</CardTitle>
        </CardHeader>
        <CardContent>
          {reportType === 'occupancy' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-muted rounded-lg text-center">
                  <p className="text-2xl font-bold">{kpis.totalProperties}</p>
                  <p className="text-sm text-muted-foreground">Total Propiedades</p>
                </div>
                <div className="p-4 bg-[#38a169]/10 rounded-lg text-center">
                  <p className="text-2xl font-bold text-[#38a169]">{kpis.rentedProperties}</p>
                  <p className="text-sm text-muted-foreground">Alquiladas</p>
                </div>
                <div className="p-4 bg-[#d69e2e]/10 rounded-lg text-center">
                  <p className="text-2xl font-bold text-[#d69e2e]">{kpis.availableProperties}</p>
                  <p className="text-sm text-muted-foreground">Disponibles</p>
                </div>
              </div>
              <div className="h-4 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-[#38a169] rounded-full" style={{ width: `${kpis.occupancyRate}%` }}></div>
              </div>
            </div>
          )}
          {reportType === 'revenue' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-[#38a169]/10 rounded-lg">
                  <p className="text-sm text-muted-foreground">Ingresos Mensuales</p>
                  <p className="text-3xl font-bold text-[#38a169]">{kpis.totalRevenue.toLocaleString('es-ES')}€</p>
                </div>
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">Ingresos Anuales Proyectados</p>
                  <p className="text-3xl font-bold">{(kpis.totalRevenue * 12).toLocaleString('es-ES')}€</p>
                </div>
              </div>
            </div>
          )}
          {reportType === 'maintenance' && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="p-4 bg-yellow-100 rounded-lg text-center">
                  <p className="text-2xl font-bold text-yellow-700">{serviceRequests.filter(r => r.status === 'pending').length}</p>
                  <p className="text-sm text-muted-foreground">Pendientes</p>
                </div>
                <div className="p-4 bg-blue-100 rounded-lg text-center">
                  <p className="text-2xl font-bold text-blue-700">{serviceRequests.filter(r => r.status === 'in_progress').length}</p>
                  <p className="text-sm text-muted-foreground">En Progreso</p>
                </div>
                <div className="p-4 bg-green-100 rounded-lg text-center">
                  <p className="text-2xl font-bold text-green-700">{serviceRequests.filter(r => r.status === 'resolved').length}</p>
                  <p className="text-sm text-muted-foreground">Resueltas</p>
                </div>
                <div className="p-4 bg-red-100 rounded-lg text-center">
                  <p className="text-2xl font-bold text-red-700">{serviceRequests.filter(r => r.priority === 'urgent').length}</p>
                  <p className="text-sm text-muted-foreground">Urgentes</p>
                </div>
              </div>
            </div>
          )}
          {reportType === 'contracts' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-[#38a169]/10 rounded-lg text-center">
                  <p className="text-2xl font-bold text-[#38a169]">{contracts.filter(c => c.status === 'active').length}</p>
                  <p className="text-sm text-muted-foreground">Activos</p>
                </div>
                <div className="p-4 bg-[#d69e2e]/10 rounded-lg text-center">
                  <p className="text-2xl font-bold text-[#d69e2e]">2</p>
                  <p className="text-sm text-muted-foreground">Próximos a Vencer</p>
                </div>
                <div className="p-4 bg-muted rounded-lg text-center">
                  <p className="text-2xl font-bold">{contracts.filter(c => c.status === 'expired').length}</p>
                  <p className="text-sm text-muted-foreground">Vencidos</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ============ SERVICE REQUESTS ============
function ServiceRequestsSection() {
  const { user } = useAuthStore();
  const { serviceRequests, properties, updateServiceRequest, setCurrentView } = useAppStore();

  // Filter requests based on role
  const filteredRequests = serviceRequests.filter((r) => {
    if (user?.role === 'tenant') {
      return r.tenantId === 'tenant-1';
    }
    return true;
  });

  const handleStatusChange = (id: string, status: ServiceRequest['status']) => {
    updateServiceRequest(id, { 
      status, 
      updatedAt: new Date().toISOString().split('T')[0],
      ...(status === 'resolved' ? { resolvedAt: new Date().toISOString().split('T')[0] } : {})
    });
    toast({
      title: 'Estado actualizado',
      description: 'El estado de la solicitud ha sido actualizado',
    });
  };

  const categoryIcons: Record<string, React.ReactNode> = {
    plumbing: <Droplets className="h-4 w-4" />,
    electrical: <Zap className="h-4 w-4" />,
    hvac: <Wind className="h-4 w-4" />,
    structural: <Building2 className="h-4 w-4" />,
    appliance: <Settings className="h-4 w-4" />,
    other: <Wrench className="h-4 w-4" />
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Solicitudes de Servicio</h1>
          <p className="text-muted-foreground">Gestión de incidencias y solicitudes de mantenimiento</p>
        </div>
        {user?.role === 'tenant' && (
          <Button onClick={() => setCurrentView('service-form')}>
            <Plus className="h-4 w-4 mr-2" />
            Nueva Solicitud
          </Button>
        )}
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pendientes</p>
                <p className="text-2xl font-bold">{filteredRequests.filter(r => r.status === 'pending').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Wrench className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">En Progreso</p>
                <p className="text-2xl font-bold">{filteredRequests.filter(r => r.status === 'in_progress').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Resueltas</p>
                <p className="text-2xl font-bold">{filteredRequests.filter(r => r.status === 'resolved').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">
                <AlertTriangle className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Urgentes</p>
                <p className="text-2xl font-bold">{filteredRequests.filter(r => r.priority === 'urgent').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Requests List */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Solicitudes</CardTitle>
        </CardHeader>
        <CardContent className="max-h-96 overflow-y-auto scrollbar-thin">
          <div className="space-y-4">
            {filteredRequests.map((request) => {
              const property = properties.find(p => p.id === request.propertyId);
              const tenant = getTenantById(request.tenantId);

              return (
                <div key={request.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                      request.priority === 'urgent' ? 'bg-red-100' :
                      request.priority === 'high' ? 'bg-orange-100' :
                      request.priority === 'medium' ? 'bg-yellow-100' : 'bg-green-100'
                    }`}>
                      {categoryIcons[request.category]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium">{request.title}</p>
                        <Badge variant={
                          request.priority === 'urgent' ? 'destructive' :
                          request.priority === 'high' ? 'default' : 'secondary'
                        } className="text-xs">
                          {request.priority === 'urgent' ? 'Urgente' :
                           request.priority === 'high' ? 'Alta' :
                           request.priority === 'medium' ? 'Media' : 'Baja'}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{request.description}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3" />
                          {property?.name}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {tenant?.name}
                        </span>
                        <span>{new Date(request.createdAt).toLocaleDateString('es-ES')}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {user?.role === 'admin' && (
                        <Select 
                          value={request.status} 
                          onValueChange={(v) => handleStatusChange(request.id, v as ServiceRequest['status'])}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pendiente</SelectItem>
                            <SelectItem value="in_progress">En Progreso</SelectItem>
                            <SelectItem value="resolved">Resuelto</SelectItem>
                            <SelectItem value="closed">Cerrado</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                      {!user?.role?.match('admin') && (
                        <Badge variant={
                          request.status === 'pending' ? 'outline' :
                          request.status === 'in_progress' ? 'default' :
                          request.status === 'resolved' ? 'secondary' : 'destructive'
                        }>
                          {request.status === 'pending' ? 'Pendiente' :
                           request.status === 'in_progress' ? 'En Progreso' :
                           request.status === 'resolved' ? 'Resuelto' : 'Cerrado'}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ============ SERVICE REQUEST FORM ============
function ServiceRequestForm() {
  const { user } = useAuthStore();
  const { addServiceRequest, setCurrentView } = useAppStore();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'other',
    priority: 'medium'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newRequest: ServiceRequest = {
      id: `request-${Date.now()}`,
      propertyId: 'prop-1', // Demo: Juan Martínez's property
      tenantId: 'tenant-1',
      title: formData.title,
      description: formData.description,
      category: formData.category as ServiceRequest['category'],
      priority: formData.priority as ServiceRequest['priority'],
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0]
    };

    addServiceRequest(newRequest);
    toast({
      title: 'Solicitud enviada',
      description: 'Su solicitud de servicio ha sido registrada correctamente',
    });
    setCurrentView('service-requests');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => setCurrentView('service-requests')}>
          <ChevronRight className="h-4 w-4 rotate-180" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-[#1a365d]">Nueva Solicitud de Servicio</h1>
          <p className="text-muted-foreground">Reporte una incidencia o solicite mantenimiento</p>
        </div>
      </div>

      <Card className="max-w-2xl">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Detalles de la Solicitud</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Resumen breve del problema"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Categoría *</Label>
              <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="plumbing">Fontanería</SelectItem>
                  <SelectItem value="electrical">Electricidad</SelectItem>
                  <SelectItem value="hvac">Climatización</SelectItem>
                  <SelectItem value="structural">Estructural</SelectItem>
                  <SelectItem value="appliance">Electrodomésticos</SelectItem>
                  <SelectItem value="other">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Prioridad *</Label>
              <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Baja</SelectItem>
                  <SelectItem value="medium">Media</SelectItem>
                  <SelectItem value="high">Alta</SelectItem>
                  <SelectItem value="urgent">Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción Detallada *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describa el problema con el mayor detalle posible..."
                rows={5}
                required
              />
            </div>
          </CardContent>
          <div className="flex justify-end gap-4 p-6 pt-0">
            <Button type="button" variant="outline" onClick={() => setCurrentView('service-requests')}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-[#1a365d] hover:bg-[#1a365d]/90">
              Enviar Solicitud
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

// ============ MAIN APP LAYOUT ============
function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}

// ============ MAIN PAGE ============
export default function RealEstateApp() {
  const { isAuthenticated, user } = useAuthStore();
  const { currentView } = useAppStore();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const renderContent = () => {
    // Admin and Owner dashboard
    if (currentView === 'dashboard') {
      if (user?.role === 'admin') return <AdminDashboard />;
      if (user?.role === 'owner') return <OwnerDashboard />;
      return <TenantDashboard />;
    }

    // Properties
    if (currentView === 'properties') return <PropertyList />;
    if (currentView === 'property-detail') return <PropertyDetail />;
    if (currentView === 'property-form') return <PropertyForm />;

    // Contracts
    if (currentView === 'contracts') return <ContractsSection />;

    // Reports
    if (currentView === 'reports') return <ReportsSection />;

    // Service Requests
    if (currentView === 'service-requests') return <ServiceRequestsSection />;
    if (currentView === 'service-form') return <ServiceRequestForm />;

    // Default to dashboard
    return <AdminDashboard />;
  };

  return (
    <AppLayout>
      {renderContent()}
    </AppLayout>
  );
}
