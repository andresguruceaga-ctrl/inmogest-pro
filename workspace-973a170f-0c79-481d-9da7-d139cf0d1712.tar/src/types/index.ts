// User Roles
export type UserRole = 'admin' | 'owner' | 'tenant';

// User
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

// Property
export interface Property {
  id: string;
  name: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  type: 'apartment' | 'house' | 'office' | 'commercial' | 'warehouse';
  status: 'available' | 'rented' | 'maintenance';
  bedrooms: number;
  bathrooms: number;
  area: number; // square meters
  price: number; // monthly rent
  description: string;
  features: string[];
  images: string[];
  ownerId: string;
  tenantId?: string;
  createdAt: string;
  updatedAt: string;
}

// Owner
export interface Owner {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  properties: string[];
  createdAt: string;
}

// Tenant
export interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  propertyId: string;
  contractStart: string;
  contractEnd: string;
  createdAt: string;
}

// Contract
export interface Contract {
  id: string;
  propertyId: string;
  tenantId: string;
  ownerId: string;
  startDate: string;
  endDate: string;
  monthlyRent: number;
  deposit: number;
  status: 'active' | 'expired' | 'terminated';
  fileName?: string;
  fileSize?: number;
  uploadDate?: string;
  createdAt: string;
}

// Service Request
export interface ServiceRequest {
  id: string;
  propertyId: string;
  tenantId: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'resolved' | 'closed';
  category: 'plumbing' | 'electrical' | 'hvac' | 'structural' | 'appliance' | 'other';
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
}

// Dashboard KPIs
export interface DashboardKPIs {
  totalProperties: number;
  rentedProperties: number;
  availableProperties: number;
  totalRevenue: number;
  activeContracts: number;
  pendingRequests: number;
  occupancyRate: number;
  monthlyGrowth: number;
}

// Report
export interface Report {
  id: string;
  title: string;
  type: 'occupancy' | 'revenue' | 'maintenance' | 'contracts';
  dateRange: {
    start: string;
    end: string;
  };
  generatedAt: string;
  data: Record<string, unknown>[];
}
