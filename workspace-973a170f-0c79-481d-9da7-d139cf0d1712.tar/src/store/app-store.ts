'use client';

import { create } from 'zustand';
import { Property, ServiceRequest, Contract } from '@/types';
import { properties as initialProperties, serviceRequests as initialRequests, contracts as initialContracts } from '@/lib/mock-data';

interface AppState {
  // View state
  currentView: 'dashboard' | 'properties' | 'property-detail' | 'property-form' | 'contracts' | 'reports' | 'service-requests' | 'service-form';
  selectedPropertyId: string | null;
  
  // Data
  properties: Property[];
  serviceRequests: ServiceRequest[];
  contracts: Contract[];
  
  // Actions
  setCurrentView: (view: AppState['currentView']) => void;
  setSelectedPropertyId: (id: string | null) => void;
  addProperty: (property: Property) => void;
  updateProperty: (id: string, property: Partial<Property>) => void;
  deleteProperty: (id: string) => void;
  addServiceRequest: (request: ServiceRequest) => void;
  updateServiceRequest: (id: string, request: Partial<ServiceRequest>) => void;
  addContract: (contract: Contract) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentView: 'dashboard',
  selectedPropertyId: null,
  properties: initialProperties,
  serviceRequests: initialRequests,
  contracts: initialContracts,
  
  setCurrentView: (view) => set({ currentView: view }),
  setSelectedPropertyId: (id) => set({ selectedPropertyId: id }),
  
  addProperty: (property) => set((state) => ({
    properties: [...state.properties, property]
  })),
  
  updateProperty: (id, property) => set((state) => ({
    properties: state.properties.map(p => p.id === id ? { ...p, ...property } : p)
  })),
  
  deleteProperty: (id) => set((state) => ({
    properties: state.properties.filter(p => p.id !== id)
  })),
  
  addServiceRequest: (request) => set((state) => ({
    serviceRequests: [...state.serviceRequests, request]
  })),
  
  updateServiceRequest: (id, request) => set((state) => ({
    serviceRequests: state.serviceRequests.map(r => r.id === id ? { ...r, ...request } : r)
  })),
  
  addContract: (contract) => set((state) => ({
    contracts: [...state.contracts, contract]
  }))
}));
